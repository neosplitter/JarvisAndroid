package de.dirk.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var status by mutableStateOf("Bereit. API-Schlüssel eintragen und Verbindung testen.")
    private var answer by mutableStateOf("Guten Tag. Ich bin Jarvis. Wie kann ich Ihnen helfen?")
    private var busy by mutableStateOf(false)
    private var apiKey by mutableStateOf("")
    private var command by mutableStateOf("")
    private val prefs by lazy { getSharedPreferences("jarvis_local", MODE_PRIVATE) }

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecognition() else status = "Mikrofonzugriff wurde nicht erlaubt."
    }
    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            command = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (command.isNotBlank()) askGemini(command)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apiKey = prefs.getString("gemini_key", "") ?: ""
        tts = TextToSpeech(this, this)
        setContent {
            JarvisUi(
                status, answer, busy, apiKey, command,
                onKey = { apiKey = it; prefs.edit().putString("gemini_key", it.trim()).apply() },
                onCommand = { command = it },
                onAsk = { askGemini(command) },
                onListen = { requestMic() },
                onSpeak = { speak(answer) },
                onClear = { answer = "Gespräch zurückgesetzt."; status = "Bereit." }
            )
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val lang = tts?.setLanguage(Locale.GERMANY)
            tts?.setSpeechRate(0.91f)
            tts?.setPitch(0.88f)
            ttsReady = lang != TextToSpeech.LANG_MISSING_DATA && lang != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) status = "Deutsche Android-Sprachausgabe nicht verfügbar. Bitte deutsche Stimme installieren."
        } else status = "Sprachausgabe konnte nicht gestartet werden."
    }

    private fun speak(text: String) {
        if (ttsReady && text.isNotBlank()) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun requestMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecognition()
        else permission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Ihre Anweisung an Jarvis")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { speech.launch(intent) } catch (_: Exception) { status = "Spracherkennung ist auf diesem Gerät nicht verfügbar." }
    }

    private data class ApiResult(val text: String, val code: Int)

    private fun askGemini(prompt: String) {
        val key = apiKey.trim()
        if (key.isBlank()) { status = "Bitte zuerst den Gemini-API-Schlüssel eintragen."; return }
        if (prompt.isBlank()) { status = "Bitte eine Frage eingeben oder sprechen."; return }
        if (busy) return
        busy = true
        status = "Jarvis analysiert …"
        thread(name = "JarvisGeminiRequest") {
            val resultText = try {
                var result = callGeminiWithRetries(key, "gemini-3.8-flash", prompt)
                if (result.code !in 200..299 && result.code in setOf(429, 500, 502, 503, 504)) {
                    result = callGeminiWithRetries(key, "gemini-3.7-flash", prompt)
                }
                if (result.code in 200..299) result.text else when (result.code) {
                    400, 401, 403 -> "Der Gemini-Zugriff wurde abgelehnt (HTTP ${result.code}). Bitte API-Schlüssel, API-Freigabe und Kontingent in Google AI Studio prüfen."
                    404 -> "Das Gemini-Modell ist für diesen API-Zugang nicht verfügbar (HTTP 404). Bitte Modellzugriff und API-Schlüssel in Google AI Studio prüfen."
                    429 -> "Das Gemini-Kontingent oder die Anfragerate ist erreicht (HTTP 429). Bitte kurz warten oder das API-Kontingent prüfen."
                    500, 502, 503, 504 -> "Gemini ist momentan stark ausgelastet. Ich habe mehrere Versuche und ein Ausweichmodell probiert. Bitte in einigen Minuten erneut versuchen."
                    else -> "Gemini-Anfrage fehlgeschlagen (HTTP ${result.code}). Bitte Verbindung und API-Einstellungen prüfen."
                }
            } catch (e: Exception) {
                "Verbindung fehlgeschlagen: ${e.localizedMessage ?: "Netzwerkfehler"}"
            }
            runOnUiThread {
                answer = resultText
                val failed = resultText.startsWith("Gemini") || resultText.startsWith("Der Gemini") ||
                    resultText.startsWith("Das Gemini") || resultText.startsWith("Verbindung")
                status = if (failed) "Verbindung prüfen" else "Antwort bereit"
                busy = false
                if (!failed) speak(resultText)
            }
        }
    }

    private fun callGeminiWithRetries(key: String, model: String, prompt: String): ApiResult {
        val retryable = setOf(429, 500, 502, 503, 504)
        var result = ApiResult("Keine Antwort erhalten.", -1)
        for (attempt in 0..2) {
            result = callGeminiOnce(key, model, prompt)
            if (result.code in 200..299 || result.code !in retryable) return result
            if (attempt < 2) Thread.sleep(1500L * (1L shl attempt))
        }
        return result
    }

    private fun callGeminiOnce(key: String, model: String, prompt: String): ApiResult {
        val encodedKey = java.net.URLEncoder.encode(key, "UTF-8")
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$encodedKey")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        return try {
            val systemText = "Du bist J.A.R.V.I.S., ein höflicher, souveräner, technisch versierter persönlicher Assistent. Antworte auf Deutsch, klar, natürlich und eher knapp. Sprich den Nutzer nicht mit Namen an. Deine Selbstbezeichnung lautet Jarvis."
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemText))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("maxOutputTokens", 900))
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                ApiResult(raw, code)
            } else {
                val json = JSONObject(raw)
                val parts = json.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")
                val text = buildString {
                    if (parts != null) for (i in 0 until parts.length()) {
                        val part = parts.optJSONObject(i)?.optString("text").orEmpty()
                        if (part.isNotBlank()) { if (isNotEmpty()) append("\n"); append(part) }
                    }
                }.ifBlank { "Ich habe leider keine Textantwort erhalten." }
                ApiResult(text, code)
            }
        } finally { conn.disconnect() }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisUi(
    status: String, answer: String, busy: Boolean, apiKey: String, command: String,
    onKey: (String) -> Unit, onCommand: (String) -> Unit, onAsk: () -> Unit,
    onListen: () -> Unit, onSpeak: () -> Unit, onClear: () -> Unit
) {
    val cyan = Color(0xFF43DFFF)
    val panel = Color(0xFF0A2233)
    MaterialTheme(colorScheme = darkColorScheme(primary = cyan, secondary = Color(0xFF168DBB))) {
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071C2D), Color(0xFF02070D))))
                .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("STARK INDUSTRIES  •  PERSONAL AI", color = cyan, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(16.dp))
            Text("J.A.R.V.I.S.", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Light, letterSpacing = 5.sp)
            Text("GEMINI INTELLIGENCE SYSTEM", color = cyan.copy(alpha = .8f), fontSize = 9.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(24.dp))
            Box(Modifier.size(158.dp).background(Brush.radialGradient(listOf(Color(0x8839DFFF), Color(0x2239DFFF), Color.Transparent)), CircleShape),
                contentAlignment = Alignment.Center) {
                Box(Modifier.size(112.dp).background(Color(0x2239DFFF), CircleShape), contentAlignment = Alignment.Center) {
                    Text("J", color = cyan, fontSize = 72.sp, fontWeight = FontWeight.Thin)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(if (busy) "ANALYSE LÄUFT" else "SYSTEM BEREIT", color = cyan, fontSize = 12.sp, letterSpacing = 3.sp)
            Text(status, color = Color(0xFFB8D7E8), fontSize = 12.sp)
            Spacer(Modifier.height(22.dp))
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("GEMINI API-SCHLÜSSEL", color = cyan, fontSize = 11.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = apiKey, onValueChange = onKey, modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("API-Schlüssel aus Google AI Studio") },
                        singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                    Text("Wird nur lokal auf diesem Gerät gespeichert. Nicht in GitHub hochladen.", color = Color.LightGray, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("DEIN AUFTRAG", color = cyan, fontSize = 11.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = command, onValueChange = onCommand, modifier = Modifier.fillMaxWidth(),
                        minLines = 2, placeholder = { Text("Was kann ich für Sie tun?") })
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onListen, modifier = Modifier.weight(1f)) { Text("🎙 Sprechen") }
                        Button(onClick = onAsk, modifier = Modifier.weight(1f), enabled = !busy) { Text("Senden") }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("J.A.R.V.I.S. ANTWORT", color = cyan, fontSize = 11.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(answer, color = Color.White, fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onSpeak) { Text("Antwort vorlesen") }
                        OutlinedButton(onClick = onClear) { Text("Zurücksetzen") }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Hinweis: Mikrofon wird nur nach Antippen aktiviert. Kein dauerndes Lauschen / kein Hey-Jarvis-Wakeword in dieser Version.",
                color = Color(0xFF89A9BA), fontSize = 10.sp)
            Spacer(Modifier.height(12.dp))
        }
    }
}

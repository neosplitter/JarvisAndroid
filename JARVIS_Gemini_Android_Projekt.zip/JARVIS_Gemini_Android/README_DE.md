# J.A.R.V.I.S. – Gemini Android-Projekt

Diese Version ersetzt die bisherige ChatGPT-Teilen-Funktion durch eine direkte Gemini-API-Anbindung.

## Enthalten
- Deutsche Spracheingabe per Android-Spracherkennung (Start per Mikrofontaste)
- Gemini 2.5 Flash als KI-Modell
- Deutsche Android-Sprachausgabe
- Blaues HUD-Design
- Scrollbare Oberfläche, damit alle Bedienelemente erreichbar sind
- API-Schlüssel wird lokal in den App-Einstellungen gespeichert

## Wichtig zu Kosten und Abo
Google AI Plus / Google One ist nicht automatisch ein Gemini-API-Guthaben. Für die API ist ein Schlüssel aus Google AI Studio erforderlich; dort gelten eigene Kontingente und ggf. Abrechnung. Vor Nutzung bitte die aktuelle Preis-/Kontingentseite prüfen. Diese App kann dadurch zusätzliche API-Kosten verursachen.

## API-Schlüssel
1. In Google AI Studio einen Gemini-API-Schlüssel erstellen.
2. APK installieren und den Schlüssel in das Feld „Gemini API-Schlüssel“ eintragen.
3. Eine Frage eintippen oder auf „Sprechen“ tippen.
4. Jarvis antwortet per Text und – sofern eine deutsche Android-TTS-Stimme installiert ist – gesprochen.

Der Schlüssel wird in den privaten App-Daten auf dem Gerät gespeichert. Er darf nicht in GitHub, Screenshots oder öffentliche Dateien kopiert werden. Eine mobile Client-App kann einen eingebetteten API-Schlüssel technisch nicht vollständig vor Zugriff schützen; nur für den persönlichen Gebrauch verwenden und bei Missbrauch widerrufen.

## APK bauen
Das Projekt ist für GitHub Actions vorbereitet. Den Inhalt dieses Ordners in dein Repository übernehmen und auf `main` pushen. Unter „Actions“ erscheint der Workflow „Build JARVIS APK“. Nach erfolgreichem Lauf liegt die APK unter „Artifacts“ als `JARVIS-Gemini-APK`.

## Bewusste Grenzen dieser Version
- Kein dauerhaftes „Hey Jarvis“-Mithören: Android beschränkt Mikrofonzugriff im Hintergrund. Die Spracheingabe wird bewusst per Taste gestartet.
- Kein Gemini-Live-Audio-Streaming; Spracherkennung und Sprachausgabe laufen über Android.
- Das Google-One-Abo selbst schaltet die Gemini-API nicht automatisch frei.

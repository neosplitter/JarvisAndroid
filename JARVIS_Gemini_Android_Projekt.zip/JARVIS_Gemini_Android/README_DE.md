# J.A.R.V.I.S. – Gemini Android-Projekt (korrigiert)

## Änderungen
- Verwendet `gemini-3.8-flash` statt des eingestellten `gemini-2.5-flash`.
- Bei temporären Fehlern (HTTP 429, 500, 502, 503, 504) erfolgen bis zu drei Versuche mit steigenden Wartezeiten.
- Bei fortbestehender Überlastung wird automatisch `gemini-3.7-flash` als Ausweichmodell probiert.
- Verständlichere Fehlermeldungen.
- Scrollbare Oberfläche, deutsche Spracheingabe per Mikrofontaste und Android-Sprachausgabe.

## Einrichtung
1. Gemini-API-Schlüssel in Google AI Studio erstellen.
2. APK installieren und Schlüssel in der App eintragen.
3. Frage eingeben oder „Sprechen“ antippen.

Der Schlüssel wird in den privaten App-Daten gespeichert. Nicht in GitHub, Screenshots oder öffentliche Dateien kopieren. Eine mobile App kann einen lokal gespeicherten API-Schlüssel nicht vollständig vor Zugriff schützen. Nur persönlich verwenden und bei Missbrauch widerrufen.

Ein Google-Gemini-Verbraucherabo ist nicht automatisch API-Guthaben. Für die Gemini Developer API gelten eigene Kontingente und gegebenenfalls separate Abrechnung.

## Grenzen
Kein dauerhaftes „Hey Jarvis“-Mithören: Android beschränkt Mikrofonzugriff im Hintergrund. Spracheingabe und Sprachausgabe laufen über Android, nicht über Gemini Live.

# J.A.R.V.I.S. Android – Sprachkorrektur (Build 2)

Diese Version korrigiert die bisherige TTS-Ausgabe:

- Gesprochener Name ist **„Jarvis“** (nicht „J.A.R.V.I.S.“ – dadurch wird der Name nicht absichtlich buchstabiert).
- Deutsche installierte TTS-Stimmen werden in der App aufgelistet.
- Eine eindeutig als männlich bezeichnete deutsche Stimme wird bevorzugt, sofern Android sie bereitstellt.
- Die Stimme kann in der App ausgewählt und mit „STIMME TESTEN“ angehört werden.
- Sprechtempo und Tonhöhe sind leicht abgesenkt.
- Die Iron-Man-inspirierte Oberfläche und die Spracherkennung `de-DE` bleiben erhalten.

## Wichtige Grenze
Android stellt Apps nicht zuverlässig ein Geschlechtsmerkmal für TTS-Stimmen bereit. Deshalb kann die App eine Männerstimme nicht erzwingen, wenn auf dem Gerät keine passende deutsche Männerstimme installiert ist. In diesem Fall zeigt die App die verfügbaren deutschen Stimmen zur Auswahl. Bitte jede Stimme mit „STIMME TESTEN“ prüfen.

## Noch nicht enthalten
- Kein dauerhaftes „Hey Jarvis“-Wake-Word im Hintergrund.
- Keine direkte Gemini-Anbindung. Der bisherige ChatGPT-Button übergibt Text weiterhin über das Android-Teilen-Menü; er ist keine integrierte KI-Verbindung.
- Keine Original-Filmstimme.

## GitHub Actions Build
1. Die ZIP-Datei `JARVIS_Android_ChatGPT_Handoff.zip` im Repository-Root durch die aktualisierte Datei ersetzen.
2. Commit direkt auf `main`.
3. Unter **Actions** den Workflow **Build JARVIS APK** öffnen.
4. Den neuesten erfolgreichen Lauf öffnen und unter **Artifacts** `JARVIS-APK` bzw. `jarvis-debug-apk` herunterladen (je nach Workflow-Datei).
5. ZIP entpacken und die APK auf dem Samsung installieren.

Die APK wurde hier nicht kompiliert oder auf einem Samsung-Gerät getestet. Erst ein grüner GitHub-Actions-Build bestätigt, dass der Quellcode erfolgreich gebaut wurde.

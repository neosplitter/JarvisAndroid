# J.A.R.V.I.S. für Android – Build 1.0

## Was diese Version kann
- Dunkelblaue, Iron-Man-inspirierte HUD-Oberfläche
- Deutsche Spracheingabe über Android-Spracherkennung
- Deutsche Sprachausgabe über Android Text-to-Speech
- Texteingabe und Übergabe einer Anweisung über das Android-Teilen-Menü
- ChatGPT kann in der Teilen-Auswahl ausgewählt werden; ChatGPT muss installiert und angemeldet sein
- Keine OpenAI-API und keine zusätzlichen API-Gebühren

## Wichtige Grenze
Diese App kann ChatGPT nicht in ihre eigene Oberfläche einbetten und Antworten nicht automatisch aus der ChatGPT-App zurücklesen. Android öffnet die Teilen-Auswahl; der Nutzer wählt ChatGPT aus und führt das Gespräch dort fort. Das ist keine offizielle ChatGPT-API-Integration.

Die App enthält kein dauerhaftes Aktivierungswort und hört nicht heimlich im Hintergrund mit. Die Spracheingabe startet erst nach Tippen auf SPRECHEN.

## APK ohne PC erstellen
1. Ein GitHub-Konto im Browser auf dem Handy öffnen.
2. Ein neues Repository namens `JarvisAndroid` anlegen.
3. Alle Dateien und Ordner aus diesem Projekt hochladen (die Ordnerstruktur beibehalten).
4. Auf GitHub den Tab **Actions** öffnen.
5. Den Workflow **Build Android APK** starten.
6. Nach erfolgreichem Lauf das Artefakt `jarvis-debug-apk` herunterladen.
7. ZIP entpacken und `app-debug.apk` auf dem Handy öffnen. Falls Android fragt, die Installation aus dieser Quelle erlauben.

## Technische Voraussetzungen
- Android 8.0 oder neuer
- ChatGPT-App installiert und angemeldet für die Übergabe
- Eine deutsche Android-TTS-Stimme für die Sprachausgabe

## Datenschutz
Sprachaufnahme wird über den Android-Spracherkennungsdienst angefordert. Die App enthält keinen API-Schlüssel und speichert keine Chatverläufe.

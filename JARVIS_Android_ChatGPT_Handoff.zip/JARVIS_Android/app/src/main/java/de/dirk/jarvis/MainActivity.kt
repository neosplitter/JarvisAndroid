package de.dirk.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var statusText by mutableStateOf("System bereit. Ich höre zu, wenn Sie mich aktivieren.")

    private val permissionRequest =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) launchSpeechRecognition()
            else statusText = "Mikrofonzugriff wurde nicht erlaubt."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            JarvisScreen(
                status = statusText,
                onListen = { requestMicrophone() },
                onTestVoice = { speak("Guten Tag. J.A.R.V.I.S. ist einsatzbereit.") },
                onSendToChatGPT = { prompt -> handOffToChatGPT(prompt) }
            )
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val languageResult = tts?.setLanguage(Locale.GERMANY)
            ttsReady = languageResult != TextToSpeech.LANG_MISSING_DATA &&
                languageResult != TextToSpeech.LANG_NOT_SUPPORTED
            if (ttsReady) speak("J.A.R.V.I.S. System online.")
            else statusText = "Bitte eine deutsche Stimme in den Android-TTS-Einstellungen installieren."
        } else {
            statusText = "Die Android-Sprachausgabe konnte nicht gestartet werden."
        }
    }

    private fun speak(message: String) {
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun requestMicrophone() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED) {
            launchSpeechRecognition()
        } else {
            permissionRequest.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun launchSpeechRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Ihre Anweisung an J.A.R.V.I.S.")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            statusText = "Auf diesem Gerät ist kein Spracherkennungsdienst verfügbar."
        }
    }

    private val speechLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val spoken = result.data
                    ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull().orEmpty()
                if (spoken.isNotBlank()) {
                    statusText = "Erkannt: $spoken"
                    handOffToChatGPT(spoken)
                }
            }
        }

    private fun handOffToChatGPT(prompt: String) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, prompt)
        }
        val chooser = Intent.createChooser(shareIntent, "An ChatGPT übergeben")
        try {
            startActivity(chooser)
            statusText = "Anweisung vorbereitet. Wählen Sie ChatGPT in der Teilen-Auswahl."
        } catch (_: Exception) {
            statusText = "Teilen nicht möglich. Bitte ChatGPT installieren."
            Toast.makeText(this, "ChatGPT konnte nicht geöffnet werden.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisScreen(
    status: String,
    onListen: () -> Unit,
    onTestVoice: () -> Unit,
    onSendToChatGPT: (String) -> Unit
) {
    var command by remember { mutableStateOf("") }
    val cyan = Color(0xFF39DFFF)
    val blue = Color(0xFF0B8DBB)
    val background = Brush.verticalGradient(listOf(Color(0xFF061B2B), Color(0xFF02060C)))
    MaterialTheme(colorScheme = darkColorScheme(primary = cyan, secondary = blue)) {
        Column(
            modifier = Modifier.fillMaxSize().background(background).padding(horizontal = 22.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("STARK INDUSTRIES  •  PERSONAL ASSISTANT", color = cyan, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(28.dp))
            Text("J.A.R.V.I.S.", color = Color.White, fontSize = 35.sp,
                fontWeight = FontWeight.Light, letterSpacing = 5.sp)
            Text("JUST A RATHER VERY INTELLIGENT SYSTEM", color = cyan.copy(alpha = .75f), fontSize = 8.sp)
            Spacer(Modifier.height(30.dp))
            Box(
                Modifier.size(205.dp).background(
                    Brush.radialGradient(listOf(Color(0x6639DFFF), Color(0x2239DFFF), Color.Transparent)),
                    CircleShape
                ),
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(152.dp).background(Color(0x2239DFFF), CircleShape),
                    contentAlignment = Alignment.Center) {
                    Text("J", color = cyan, fontSize = 86.sp, fontWeight = FontWeight.Thin)
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("SYSTEM ONLINE", color = cyan, fontSize = 12.sp, letterSpacing = 3.sp)
            Spacer(Modifier.height(12.dp))
            Text(status, color = Color(0xFFB9D8E8), fontSize = 13.sp)
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(
                value = command,
                onValueChange = { command = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Ihre Anweisung") },
                placeholder = { Text("Was kann ich für Sie tun?") },
                singleLine = false,
                maxLines = 3,
                shape = RoundedCornerShape(14.dp)
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onListen, modifier = Modifier.weight(1f)) { Text("SPRECHEN") }
                Button(
                    onClick = { if (command.isNotBlank()) onSendToChatGPT(command.trim()) },
                    modifier = Modifier.weight(1f),
                    enabled = command.isNotBlank()
                ) { Text("CHATGPT") }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onTestVoice, modifier = Modifier.fillMaxWidth()) {
                Text("STIMME TESTEN")
            }
            Spacer(Modifier.weight(1f))
            Text("SPRACHE: DEUTSCH  •  KI: CHATGPT-APP (ÜBERGABE)",
                color = Color(0xFF66899C), fontSize = 9.sp)
            Spacer(Modifier.height(4.dp))
            Text("ChatGPT muss installiert und angemeldet sein.",
                color = Color(0xFF66899C), fontSize = 9.sp)
        }
    }
}
